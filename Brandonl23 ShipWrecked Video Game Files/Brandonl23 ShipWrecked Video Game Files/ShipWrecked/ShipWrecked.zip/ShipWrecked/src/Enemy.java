import java.awt.*;
import java.awt.Graphics;

public class Enemy extends Rectangle {

    private int x, y;

    //private int hp;  (To be implemented)

    public Enemy(int x, int y, int width, int height){
        setBounds(x,y,width,height);
        this.x = x;
        this.y = y;
        this.setLocation(this.x,this.y);

    }

    public void draw(Graphics g){
        g.fillRect(this.x, this.y,this.width,this.height);
    }


    public double getY(){
        return y;
    }

    public double getX(){
        return x;
    }
}
