import java.awt.Rectangle;
import java.awt.Graphics;

public class Player extends Rectangle {

    private int dx , dy;
    private int hp;

    public Player(int x ,int y, int width, int height){
        setBounds(x,y,width,height);
        this.setLocation(ShipWreckedPanel.PANEL_WIDTH/2,ShipWreckedPanel.PANEL_HEIGHT/2);
        this.dx = 0;
        this.dy = 0;
        hp = 100;
    }

    public void update(){ //updates player
        this.x += dx;
        this.y += dy;
    }

    public void draw(Graphics g){
        g.fillRect(this.x, this.y,this.width,this.height);
    }

    public void setDx(int dx){
        this.dx = dx;
    }

    public void setDy(int dy){
        this.dy = dy;
    }

    public void setHp(int hp){
        this.hp = hp;
    }
    public int getHp(){
        return hp;
    }
}
