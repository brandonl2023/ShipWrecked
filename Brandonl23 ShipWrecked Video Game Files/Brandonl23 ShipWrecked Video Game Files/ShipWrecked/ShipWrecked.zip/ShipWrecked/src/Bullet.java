import java.awt.*;

public class Bullet extends Rectangle{

    private final int speed;

    private int damage;
    private double x;
    private double y;
    private double velocityX;
    private double velocityY;
    private double length;


    public Bullet(double x, double y, double endX, double endY){
        this.x = x;
        this.y = y;
        damage = 10;
        velocityX = endX - x;
        velocityY = endY - y;
        speed = 5;
        length = Math.sqrt(velocityX * velocityX + velocityY * velocityY);
        velocityX *= speed / length;
        velocityY *= speed / length;

    }

    public void update(){
        x += velocityX;
        y += velocityY;

    }

    public void draw(Graphics g){
        g.fillRect((int) this.x, (int) this.y, 4, 2 );


    }

    public double getY(){
        return y;
    }

    public double getX(){
        return x;
    }

    public double getVelY(){
        return velocityY;
    }

    public double getVelX(){
        return velocityX;
    }

}
