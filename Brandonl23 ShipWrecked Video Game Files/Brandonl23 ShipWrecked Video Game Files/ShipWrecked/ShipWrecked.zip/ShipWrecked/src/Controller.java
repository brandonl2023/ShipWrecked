import java.awt.*;
import java.util.ArrayList;

public class Controller {

    private ArrayList<Bullet> b = new ArrayList<>();
    private ArrayList<Enemy> e = new ArrayList<>();

    Bullet TempBullet;
    Enemy TempEnemy;
    ShipWreckedPanel panel;

    public Controller(ShipWreckedPanel panel){
        this.panel = panel;

    }

    public void update(){
        for(int i = 0; i < b.size(); i++){
            TempBullet = b.get(i);

            if(TempBullet.getY() < 0 || TempBullet.getY() > 600){  //Removes bullet when it goes above or below screen
                removeBullet(TempBullet);
                System.out.println("Off screen");
            }
            else if (TempBullet.getX() <= 0 || TempBullet.getX() > 800){ //removes bullet when goes left or right off-screen
                removeBullet(TempBullet);
                System.out.println("Off screen");
            }
            else {
                for (int j = 0; j < e.size(); j++){
                    //System.out.println(TempBullet.getX() + " " + TempBullet.getY() + " Enemy: " + e.get(j).getX() + " " + e.get(j).getY());
                    //if (TempBullet.intersects(e.get(j))){
                        removeEnemy(e.get(j));
                        removeBullet(TempBullet);
                        System.out.println("Hit");
                    //}

                }

            }

            TempBullet.update();
        }

    }

    public void draw(Graphics g) {
        for (int i = 0; i < b.size(); i++) {
            TempBullet = b.get(i);

            TempBullet.draw(g);
        }
        for (int i = 0; i < e.size(); i++){
            TempEnemy = e.get(i);

            TempEnemy.draw(g);
        }

    }

    public void addBullet(Bullet block){
        b.add(block);
    }

    public void removeBullet(Bullet block){
        b.remove(block);
    }

    public void addEnemy(Enemy block){
        e.add(block);
    }

    public void removeEnemy(Enemy block){
        e.remove(block);
    }



}
