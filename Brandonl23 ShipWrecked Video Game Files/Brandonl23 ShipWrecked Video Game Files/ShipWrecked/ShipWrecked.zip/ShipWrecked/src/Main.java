public class Main {

    public static void main(String[] args) {
        ShipWreckedFrame game = new ShipWreckedFrame();
        game.setVisible(true);

    }
}
