import java.awt.*;
import java.awt.event.*;

import javax.swing.JPanel;
import javax.swing.Timer;


public class ShipWreckedPanel extends JPanel implements ActionListener, KeyListener, MouseListener{

        public static final int PANEL_WIDTH = 800;
        public static final int PANEL_HEIGHT = 600;

        private Player p;
        private Controller c;
        private Timer t;
        private Enemy e;


        public ShipWreckedPanel(){
                setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
                p = new Player(10,10,10,10);
                c = new Controller(this);
                t = new Timer(10,this);
                // e = new Enemy(100,100,15,15);
                addKeyListener(this);
                addMouseListener(this);
                setFocusable(true);

                t.start();
        }
        public void actionPerformed(ActionEvent arg0){
                p.update();
                c.update();
                //e.update();
                repaint();
        }
        public void paint(Graphics g){
                g.clearRect(0,0,getWidth(),getHeight());
                p.draw(g);
                c.draw(g);
                //e.draw(g);
        }

        // Keys and mouse
        public void keyPressed(KeyEvent k){
                int key = k.getKeyCode();
                switch(k.getKeyCode()) {
                        case KeyEvent.VK_D:
                                p.setDx(1);
                                break;
                        case KeyEvent.VK_S:
                                p.setDy(1);
                                break;
                        case KeyEvent.VK_A:
                                p.setDx(-1);
                                break;
                        case KeyEvent.VK_W:
                                p.setDy(-1);
                                break;

                }
                if (key == KeyEvent.VK_SPACE){
                        c.addEnemy(new Enemy(300,100, 20, 20));
                        System.out.println("New Enemy");
                }
                if (key == KeyEvent.VK_F){
                        c.removeEnemy(c.TempEnemy);
                }

        }
        public void keyReleased(KeyEvent k){
                switch(k.getKeyCode()) {
                        case KeyEvent.VK_D:
                                p.setDx(0);
                                break;
                        case KeyEvent.VK_S:
                                p.setDy(0);
                                break;
                        case KeyEvent.VK_A:
                                p.setDx(0);
                                break;
                        case KeyEvent.VK_W:
                                p.setDy(0);
                                break;

                }
        }

        public void keyTyped(KeyEvent arg0){

        }


        @Override
        public void mouseClicked(MouseEvent e) {

        }

        public void mousePressed(MouseEvent e){
                c.addBullet(new Bullet(p.getX(), p.getY(), e.getX(), e.getY()));
                System.out.println("Click");
                System.out.println(e.getX() + " " + e.getY());
        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }



}
