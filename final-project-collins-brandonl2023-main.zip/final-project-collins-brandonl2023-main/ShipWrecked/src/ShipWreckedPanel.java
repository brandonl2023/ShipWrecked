import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class ShipWreckedPanel extends JPanel { // a BreakoutPanel IS-A JPanel

        public static final int PANEL_WIDTH = 800;
        public static final int PANEL_HEIGHT = 600;

        private Font timeFont; // that HAS-A score font
        private Image background; // and HAS-A background image

}
